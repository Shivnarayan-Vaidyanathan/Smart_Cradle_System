import RPi.GPIO as GPIO
import time
import servomotor
import gmail
from picamera import PiCamera
from time import sleep
GPIO.setwarnings(False)
import camera
#GPIO.setmode(GPIO.BOARD)
GPIO.setup(17, GPIO.IN)#Read output from PIR motion sensor
GPIO.setup(14, GPIO.IN)#Read output from PIR motion sensor
import temp

def main():
    
        i=GPIO.input(17)
        j=GPIO.input(14)
        humidity,temperature=temp.main()

        if i==0:                 #When output from motion sensor is LOW
            print ("No movement")
            time.sleep(1)
        if i==1:               #When output from motion sensor is HIGH
            print ("movement detected")
            time.sleep(1)
            servomotor.main()
        if j==1:                 #When output from motion sensor is LOW
            print ("No wet")
            time.sleep(1)
        if j==0:               #When output from motion sensor is HIGH
            print ("wet detected")
        time.sleep(2)
        return i,j,humidity,temperature

                

#main()