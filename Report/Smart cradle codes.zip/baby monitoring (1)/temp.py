import sys
import Adafruit_DHT
import time

def main():

    humidity, temperature = Adafruit_DHT.read_retry(11, 15)
    print(humidity,temperature)
    print ('Temp: {0:0.1f} C  Humidity: {1:0.1f} %'.format(temperature, humidity))
    time.sleep(1)
    return humidity,temperature