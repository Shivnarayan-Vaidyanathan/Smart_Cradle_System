
from picamera import PiCamera
from time import sleep
import cv2
def main():
    print("starting camera")
    camera = PiCamera()
    camera.start_preview()
    sleep(5)
    camera.capture('baby.jpg')
    camera.stop_preview()
    camera.close() 
    filename = 'baby.jpg'
    img=cv2.imread("baby.jpg")
    cv2.imshow("Frame", img)
    cv2.waitKey(0)
    print("image captured")
#main()