from firebase import firebase
firebase = firebase.FirebaseApplication('https://baby-monitoring-4a0f5-default-rtdb.firebaseio.com/', None)
import time
import cv2
import imutils
import os
import smtplib 
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email import encoders
import pyfiglet
from datetime import datetime
import camera
#import stepper
import main
import servomotor
def mail():
    fromaddr = "eration6@gmail.com"
    toaddr = "kannihya@gmail.com"
    # instance of MIMEMultipart 
    msg = MIMEMultipart() 
    # storing the senders email address   
    msg['From'] = fromaddr 
    # storing the receivers email address  
    msg['To'] = toaddr 
    # storing the subject  
    msg['Subject'] = "Image"
    # string to store the body of the mail 
    body = "Hi, find the attached Image"
    
    # attach the body with the msg instance 
    msg.attach(MIMEText(body, 'plain')) 
           
    # open the file to be sent
    camera.main()
    filename="baby.jpg"
    attachment = open(filename, "rb")
    
    # instance of MIMEBase and named as p 
    p = MIMEBase('application', 'octet-stream') 
    
    # To change the payload into encoded form 
    p.set_payload((attachment).read())
    
    # encode into base64 
    encoders.encode_base64(p)
    
    # attach the instance 'p' to instance 'msg'
    
    p.add_header('Content-Disposition', "attachment; filename= %s" % filename)
    msg.attach(p) 
    
    # creates SMTP session 
    s = smtplib.SMTP('smtp.gmail.com', 587) 
    
    # start TLS for security 
    s.starttls() 
    # Authentication 
    s.login(fromaddr,"Project@123") 
    # Converts the Multipart msg into a string 
    text = msg.as_string() 
    
    # sending the mail 
    s.sendmail(fromaddr, toaddr, text) 
    
    # terminating the session 
    s.quit()

    



while True:
  i,j,humidity,temperature=main.main()
  print("all sensor values",i,j,humidity,temperature)
  send_email = firebase.get('send_email',None)
  print("mail value",send_email)
  s1 = firebase.get('servo',None)
  print("servo value",s1)
  firebase.put("",'movement',i)
  firebase.put("",'temperature',temperature)
  firebase.put("",'humidity',humidity)
  firebase.put("",'wet',j)

  if s1 == "1":
    #cv2.imwrite("C:/Users/Admin/Desktop/PROJECT_CODE/image.jpg",frame)
    print("########## moving cradle ############\n")
    servomotor.main()
    firebase.put('','servo',"0")

  if send_email == "1":
    #cv2.imwrite("C:/Users/Admin/Desktop/PROJECT_CODE/image.jpg",frame)
    print("########## SENDING EMAIL ############\n")
    mail()
    print("............\n")
    print("########## EMAIL SENT ############\n")
    firebase.put('','send_email',"0")


cv2.destroyAllWindows()
cap.release()
