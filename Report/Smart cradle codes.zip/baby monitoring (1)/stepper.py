from time import sleep
import RPi.GPIO as GPIO
from RpiMotorLib import RpiMotorLib

#define GPIO pins
GPIO_pins = (14, 15, 18) # Microstep Resolution MS1-MS3 -> GPIO Pin
direction= 20       # Direction -> GPIO Pin
step = 21      # Step -> GPIO Pin

# Declare an named instance of class pass GPIO pins numbers
mymotortest = RpiMotorLib.A4988Nema(direction, step, GPIO_pins, "A4988")


 
def test(angle):


       print("Rotating Anti Clockwise")
       mymotortest.motor_go(False, "1/8" , angle,.01, False, 0.5)

       sleep(4)
       print("Rotating Clockwise")
       mymotortest.motor_go(True, "1/8" , angle,.01, False, 0.5)

# test(325)
    
 
